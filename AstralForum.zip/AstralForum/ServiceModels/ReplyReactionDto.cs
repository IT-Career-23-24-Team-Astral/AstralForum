﻿using AstralForum.Data.Entities.Reaction;
using AstralForum.Data.Entities.Reply;

/*namespace AstralForum.ServiceModels
{
    public class ReplyReactionDto : MetaBaseEntityDto
    {
        public ReactionTypeDto ReactionType { get; set; }

        public int ReplyId { get; set; }

        public ReplyDto Reply { get; set; }

        public DateTime? ModifiedOn { get; set; }

    }
}*/
