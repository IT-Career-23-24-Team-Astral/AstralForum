﻿namespace AstralForum.ServiceModels
{
    public class BaseEntityDto
    {
        public int Id { get; set; }
    }
}
