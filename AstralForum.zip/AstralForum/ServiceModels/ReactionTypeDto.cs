﻿namespace AstralForum.ServiceModels
{
    public class ReactionTypeDto : MetaBaseEntityDto
    {
        public string ImageUrl { get; set; }
    }
}
