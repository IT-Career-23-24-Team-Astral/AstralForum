﻿namespace AstralForum.Data.Entities.Tag
{
    public class TagType : BaseEntity
    {
    }
}
