﻿namespace AstralForum.Data.Entities.Thread
{
	public class Post
	{
	}
}