﻿namespace AstralForum.Data.Enums
{
    public enum NotificationType
    {
        Comment,
        Reply,
        Post,
         Ban,
         DeletedView,
         HiddenPost
    }
}
