﻿using AstralForum.ServiceModels;

namespace AstralForum.Models.Admin
{
    public class AllUsersViewModel
    {
        public List<UserDto> Users { get; set; }
    }
}
