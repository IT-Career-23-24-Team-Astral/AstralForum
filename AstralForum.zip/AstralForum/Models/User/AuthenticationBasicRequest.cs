﻿namespace AstralForum.Models.User
{
	public class AuthenticationBasicRequest
	{
		public string ReturnUrl { get; set; } = string.Empty;
	}
}
