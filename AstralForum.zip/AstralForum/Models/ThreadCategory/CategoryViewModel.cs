﻿using AstralForum.ServiceModels;

namespace AstralForum.Models.ThreadCategory
{
	public class CategoryViewModel
	{
		public List<CategoryIndexViewModel> Categories { get; set; }
	}
}
