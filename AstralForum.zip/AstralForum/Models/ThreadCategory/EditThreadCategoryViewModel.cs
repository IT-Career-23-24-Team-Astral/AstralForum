﻿namespace AstralForum.Models.ThreadCategory
{
    public class EditThreadCategoryViewModel
    {
        public int Id { get; set; }
        public string ImageUrl { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        
    }
}
