﻿namespace AstralForum.Settings
{
    public class SendGridSettings
    {
    
        public string ApiKey { get; set;}
        public string FromEmail { get; set;}
        public string EmailName { get; set; }

    }
}
