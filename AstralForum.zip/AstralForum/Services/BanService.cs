﻿namespace AstralForum.Services
{
    public class BanService
    {
    }
}
