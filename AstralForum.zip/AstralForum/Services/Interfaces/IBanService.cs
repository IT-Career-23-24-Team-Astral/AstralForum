﻿namespace AstralForum.Services.Interfaces
{
    public interface IBanService
    {
    }
}
