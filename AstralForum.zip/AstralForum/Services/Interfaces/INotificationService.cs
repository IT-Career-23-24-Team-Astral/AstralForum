﻿namespace AstralForum.Services
{
    public interface INotificationService
    {
    }
}
